from flask import Flask , render_template , request , session , redirect , jsonify
from subprocess import call 
import subprocess
import os
import pandas as pd

df1 = pd.read_csv('data/out1.csv')
print(df1.iloc[0:1,0:2])