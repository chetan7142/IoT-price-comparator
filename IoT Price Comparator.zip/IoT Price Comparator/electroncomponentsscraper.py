from scrapy import Spider
import numpy as np

class IotScraper(Spider):

    name="iotscraper"
    start_urls= []

    def __init__(self,search,**kwargs):
        super().__init__(self.name,**kwargs)
        self.start_urls=[f'https://www.electroncomponents.com/index.php?route=product/search&filter_name={search}']


    def parse(self,response):

        products = response.css('.product-list')
        for item in products:

            img = item.css('.image img::attr(src)').extract_first()
            link = item.css('.image a::attr(href)').extract_first()
            title = item.css('.name a::text').extract_first()
            price = item.css('.price::text').extract_first()
            
            if price:
                if ',' in price:
                    price = price.replace(',','')
                if 'rs.' in price.lower():
                    price = price.lower().replace('rs.','')
                try:
                    price = float(price)
                except Exception as e:
                    print(e)
                    price = np.NaN
            else:
                print('no price found')
                price = np.NaN 
            yield{
                'img':img,
                'link':link,
                'title':title,
                'price':price,
            }
