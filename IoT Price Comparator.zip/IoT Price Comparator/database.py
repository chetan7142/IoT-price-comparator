import sqlite3
class Database:
    table = 'user'
    def __init__(self , name="mydb.sqlite3"):
        self.con = sqlite3.connect(name)
        print("connected")
    def run(self,query):  #function to execte query:
        try:
            self.con.execute(query)
            self.con.commit() # saves the changes
            return True
        except Exception as e:
            print ("error")
            print(query)
            return False
    def create_table(self):
        query = f"""
        CREATE TABLE user(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            email TEXT,
            mobile TEXT
        )
        """
        return self.run(query)
    def add(self,username ,password,email,mobile):
        query=f"""
        INSERT INTO {self.table} VALUES(null , '{username}','{password}','{email}','{mobile}')
        """
        return self.run(query)
    def delete(self,id):
        query=f"""
        DELETE FROM {self.table} WHERE id = {id}
        """
        return self.run(query)
    def view(self):
        query = f"SELECT * FROM {self.table}"
        try:
            result = self.con.execute(query)
            return result.fetchall()
        except Exception as e:
            print('error')
            print (e)
    
    def getUser(self,email,password):
        query = f"SELECT * FROM {self.table} where email like '{email}' AND password like '{password}'"
        try:
            result = self.con.execute(query)
            return result.fetchall()
        except Exception as e:
            print(query)
            print (e)

    def close(self):
        self.con.close()