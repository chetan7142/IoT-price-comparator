from scrapy import Spider
import numpy as np

class IotScraper(Spider):

    name="iotscraper"
    start_urls= []

    def __init__(self,search,**kwargs):
        super().__init__(self.name,**kwargs)
        self.start_urls=[f'https://robu.in/?search_category=&s={search}&search_posttype=product&search_sku=1']


    def parse(self,response):

        products = response.css('.item')
        for item in products:

            img = item.css('.item-img img.wp-post-image::attr(src)').extract_first()
            link = item.css('.item-img a::attr(href)').extract_first()
            title = item.css('h4 a::text').extract_first()
            price = item.css('.item-price .amount::text').extract_first()
            if price:
                if ',' in price:
                    price = price.replace(',','')
                if 'rs.' in price.lower():
                    price = price.lower().replace('rs.','')
                try:
                    price = float(price)
                except Exception as e:
                    print(e)
                    price = np.NaN
            else:
                print('no price found')
                price = np.NaN 
            yield{
                'img':img,
                'link':link,
                'title':title,
                'price':price,
            }
