from flask import Flask , render_template , request , session , redirect , jsonify,flash
from subprocess import call 
import subprocess
import os
from database import Database
import pandas as pd
pd.set_option('display.max_colwidth',-1)

app = Flask(__name__)
app.secret_key = "suraj"

db = Database()
db.create_table()
db.close()

@app.route('/')
def index():
	try:
		if session.get('logged'):
			print("login successful")
			return render_template('index.html' ,opt = "aftersignleftpaneloptions.html")
		else:
			print('not logged in')
			return render_template('index.html' ,opt = "leftpaneloptions.html")
	except:
		print('not logged in')
		return render_template('index.html' ,opt = "leftpaneloptions.html")


@app.route('/signin' , methods=["POST" , "GET"])
def signin():
	if request.method == "POST":
		password = request.form.get('password')
		email = request.form.get('email')
		if password and email:
			db = Database()
			view = db.getUser(email,password)
			print(view)
			if view:
				session['logged']=True
				session['email']=email
				flash("success",'success')
				return redirect('/')
			else:
				flash('invalid credentials','danger')
				return redirect('/signin')
		else:
			flash('add credentials','danger')
			return redirect('/signin')
	else:
		return render_template('signinpage.html')

@app.route('/signup' , methods=['POST','GET'])
def signup():
	if request.method == "POST":
		username = request.form.get('username')
		password = request.form.get('password')
		email = request.form.get('email')
		mobile = request.form.get('mobile')
		if mobile and username and email and password:
			db = Database()
			db.add(username,password,email,mobile)
			flash('success, login to continue','success')
			redirect('/signin')
		else:
			flash('error registering','danger')
	return render_template('signuppage.html')

@app.route('/logout')
def logout():
	try:
		session.clear()
		return render_template('logout.html')
	except:
		session.clear()
		return render_template('logout.html')

@app.route('/feedback')
def feedback():
	return render_template('feedback.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/search')
def search():
    return render_template('search.html')
    
@app.route('/crawledoutput' , methods = ['POST' , 'GET'])
def crawledoutput():
	try:
		pd.set_option('display.max_colwidth',-1)
		df1 = pd.read_csv('data/out1.csv')

		print(df1.shape)
		return render_template('crawledoutput.html' , data = df1.to_html())
	except Exception as e:
		print(e)
		return render_template('crawledoutput.html')

# @app.route('/b_output')
# def b_output():
# 	df = pd.read_csv('data/out1.csv')
# 	df.dropna(subset=['price'],inplace = True)
# 	df["price"] = df["price"].str.replace(",","")
# 	df["price"] = df["price"].str.replace("Rs.","")
# 	# df.drop(df.loc[df['price'] == 'price']:'price')	
# 	# df.info()
# 	# print(df["price"])
# 	return render_template('b_output.html')


@app.route('/fetch_request' , methods=["POST","GET"])
def fetch_request():
	if request.method == "POST":
		
		if os.path.exists('data/out1.csv'):
			os.unlink('data/out1.csv')
		search_item = request.form.get('search')

		search_item = search_item.replace(' ','+')
		print (search_item)
		command = f"scrapy runspider robuscrapper.py -o data/out1.csv -a search={search_item}"
		try:
			request_status = subprocess.check_output(command.split() , shell=True)
		except subprocess.CalledProcessError as e:
			print(e)
		search_item = search_item.replace('+','%20')
		command = f"scrapy runspider electroncomponentsscraper.py -o data/out1.csv -a search={search_item}"
		try:
			request_status = subprocess.check_output(command.split() , shell=True)
		except subprocess.CalledProcessError as e:
			print(e)
		command = f"scrapy runspider electronicscompscraper.py -o data/out1.csv -a search={search_item}"
		try:
			request_status = subprocess.check_output(command.split() , shell=True)
			
		except subprocess.CalledProcessError as e:
			print(e)
		return redirect('/crawledoutput')
	return render_template('search.html')
	


if __name__ == "__main__":
    app.run( host="0.0.0.0" ,port=80 , debug = True)